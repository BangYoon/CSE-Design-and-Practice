#include "rangearray.h"
#include <iostream>
#include <stdlib.h>
using namespace std;
RangeArray::RangeArray(int l, int h):Array(h-l+1)
{
	low = l;
	high = h;
	//memory assignment << automatically done by inheritance
}
RangeArray::~RangeArray()
{
	// automatically done by inheritance
}
int RangeArray::baseValue()
{
	return low;// return first index
}
int RangeArray::endValue()
{
	return high;//return last index
}
int& RangeArray::operator[](int i)
{
	return Array::operator [](i-low);
	//same as array[] operator
}
int RangeArray::operator[](int i) const
{
	return Array::operator [](i-low);
	//same as array[] operator
}

