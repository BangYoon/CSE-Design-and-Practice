#include "Array.h"
#include <iostream>
#include <stdlib.h>
using namespace std;

Array::Array(int size)
{
	if (size < 0) 
	{
		cout<<"Array bound error!"<<endl;
		return;
	}
	else 
	{
		len = size;
		data = new int[size];
	}
	//memory assignment and if size is negative print error
}
Array::~Array()
{
	delete[] data;//free memory 
}
int Array::length() const
{
	return len;// return length of array
}
int &Array::operator[](int i)
{
	static int tmp;
	if (i < 0 || i > len) 
	{
		cout<<"Array bound error!"<<endl;
		return tmp;
	}
	else
		return data[i];
	//left value
}
int Array::operator[] (int i)const
{
	if (i < 0 || i > len) 
	{
		cout<<"Array bound error!"<<endl;
		return 0;
	}
	else
		return data[i];
	//right value
}
void Array::print()
{
	if (len == 0) return;
	cout<<"["<<data[0];
	for (int i = 1; i < len-1; i++)
		cout<<" "<<data[i];
	
	if (len > 1)
		cout<<" "<<data[len-1]<<"]"<<endl;
	//print
}

