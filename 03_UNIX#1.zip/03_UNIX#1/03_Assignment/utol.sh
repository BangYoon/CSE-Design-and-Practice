echo "working directory:"
flag=0
read tempdir
ent=`echo -e "\n"` 
case "$tempdir" in
$ent ) flag=1 ;;
* ) if [ -d $tempdir ]
     then
         cd $tempdir
         flag=1
        else
         flag=0
         echo "디렉토리가 존재하지 않습니다."
        fi ;;
esac
if [ $flag -eq 1 ]
then
        for tempfile in *
        do
                i=0
                newname=""
                while [ $i -lt ${#tempfile} ]
                do
                 tempchar=`echo ${tempfile:$i:1}`
                 tempchar=`echo $tempchar | tr "[a-zA-Z]" "[A-Za-z]"`
                 newname=$newname$tempchar 
                 i=`expr $i + 1`
                done
                mv $tempfile $newname   
        done
fi
