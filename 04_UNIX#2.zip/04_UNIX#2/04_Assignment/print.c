#include "header.h"
void Output(int number[])
{
	int i;
	for(i = 0; i < 10; i++)
		printf("%d ", number[i]);
	printf("\n");
}
