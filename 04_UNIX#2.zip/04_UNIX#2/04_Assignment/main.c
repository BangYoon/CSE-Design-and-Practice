#include "header.h"
int main()
{
	int i, length, T;
	int a;
	for(scanf("%d", &T), i=0; i < T; i++)
	{
		scanf("%d", &a);
		cal(a);
	}
	return 0;	
}

