#include<stdio.h>
void Output(int number[]);
void cal(const int n);
void Initialize(long int number[]);
