#include "StdAfx.h"
#include "MyHeader.h"


CASES *testcases;
int testCaseNum;
int currentCase;
char *resultString;

int P[NODE_MAX_NUM];

void F1()
{
	for ( int i = 0 ; i < NODE_MAX_NUM ; i++ ) 
		P[i] = -1;
	testCaseNum = 0;
	currentCase = 0;
	if( testcases != NULL )
	{
		delete [] testcases;
		testcases = NULL;
	}
	if( resultString != NULL )
	{
		delete [] resultString;
		resultString = NULL;
	}
	resultString = new char[256];
}

void F2(const char* fn)
{
	FILE *fp = fopen(fn,"r");
	if (fp==NULL) 
		return;

	fscanf(fp,"%d",&testCaseNum);
	testcases = new CASES[testCaseNum];
	for ( int i = 0 ; i < testCaseNum ; i++ ) 
	{
		int n;
		fscanf(fp,"%d",&n);
		testcases[i].k = n;
		for ( int j = 0 ; j < n ; j++ ) 
		{
			fscanf(fp,"%d %d",&testcases[i].x[j],&testcases[i].y[j]);
		}
	}
	fclose(fp);
}

char* F3(int n)
{
	if( resultString == NULL )
		return NULL;

	for ( int i = 0 ; i < NODE_MAX_NUM ; i++ ) 
	{
		P[i] = -1;
	}

	sprintf(resultString, "Case %d is not a tree.", n);

	for ( int i = 0 ; i < testcases[n-1].k ; i++ ) 
	{
		int x = testcases[n-1].x[i];
		int y = testcases[n-1].y[i];

		if ( P[x] == -1 ) 
			P[x] = 0;
		if ( P[y] <= 0 ) 
			P[y] = x;
		else 
			return resultString;
	}
	int count = 0;
	for ( int i = 0 ; i < NODE_MAX_NUM ; i++ ) 
	{
		if ( P[i] == 0 ) 
			count++;
	}

	if ( count >= 2 ) 
		return resultString;

	if ( !Cycle_check(P))
		sprintf(resultString, "Case %d is a tree.", n);


	return resultString;
}

bool Cycle_check( int p[])
{
	int flag[NODE_MAX_NUM], i, j;
	for(j = 0; j < NODE_MAX_NUM; j++)
	{
		if (P[j] <= 0 )
			continue;
		for(i = 0; i < NODE_MAX_NUM; i++)
			flag[i] = -1;
		if ( dfs ( P, flag, j ) == true )
			return true; 
	}
	return false;
}

bool dfs(int p[], int flag[], int c)
{
	flag[c] = 1;
	if ( P[c] == 0 ) 
		return false;	
	else if ( flag[P[c]] == 1 )
		return true;	
	else
		return dfs(P, flag, P[c]);
}