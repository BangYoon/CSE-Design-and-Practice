#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct _maze* pmaze;
typedef struct _maze
{
	int num, right, down;
}maze;

int main()
{
	int m, n, i, j, c = 0, wall, num;
	int breakwall = 0, maxbreak;
	FILE* fp;
	pmaze* r;

	fp = fopen("maze.maz", "w");
	printf("WIDTH  : ");
	scanf("%d", &n);
	printf("HEIGHT : ");
	scanf("%d", &m);

	if (m > n)
		maxbreak = n;
	else
		maxbreak = m;
	maxbreak = maxbreak / 2;

	srand((unsigned)time(NULL));
	r = (pmaze*)malloc(sizeof(pmaze) * 2);
	r[0] = (pmaze)malloc(sizeof(maze)*n);
	r[1] = (pmaze)malloc(sizeof(maze)*n);

	for (i = 0; i < n; i++)
		r[0][i].num = i;
	num = n;

	for (i = 0; i < n; i++)
	{
		fprintf(fp, "+");
		fprintf(fp, "-");
	}
	fprintf(fp, "+");

	for (i = 0; i < n; i++)
	{
		r[0][i].down = 1;
		r[0][i].right = 1;
	}

	while (c != m - 1)
	{
		for (i = 0; i < n - 1; i++)
		{
			if (r[0][i + 1].num != r[0][i].num)
			{
				wall = rand() % 2;
				r[0][i].right = wall;
			}
			else
			{
				r[0][i].right = 1;
				wall = rand() % 2;
				if (wall == 0)
				{
					if (maxbreak > breakwall)
					{
						r[0][i].right = 0;
						r[0][i + 1].num = r[0][i].num;
						r[0][i].right = 1;
						breakwall++;
					}
				}
			}
		}
		r[0][n - 1].right = 1;

		i = 0;
		while (1)
		{
			int same = 1;
			int rwall;
			for (i; i < n; i++)
			{
				if (r[0][i].num == r[0][i + 1].num)
					same++;
				else
				{
					i++;
					break;
				}
			}

			if (same == 1)
			{
				r[0][i - same].down = 0;
				r[1][i - same].num = r[0][i - same].num;
			}
			else
			{
				rwall = rand() % same;
				r[0][i - same + rwall].down = 0;
				r[1][i - same + rwall].num = r[0][i - same + rwall].num;
			}
			if (i == n) break;
		}

		for (i = 0; i<n; i++)
		{
			if (r[0][i].down != 0)
			{
				wall = rand() % 2;
				if (wall == 0)
				{
					r[0][i].down = 0;
					r[1][i].num = r[0][i].num;
				}
				else
				{
					r[0][i].down = 1;
					num++;
					r[1][i].num = num;
					wall = rand() % 2;
					if (wall == 0)
					{
						if (maxbreak > breakwall)
						{
							r[0][i].down = 0;
							r[1][i].num = r[0][i].num;
							breakwall++;
						}
					}
				}
			}
			else
			{
				wall = rand() % 2;
				if (wall == 0)
				{
					if (maxbreak > breakwall)
					{
						r[0][i].down = 0;
						r[1][i].num = r[0][i].num;
						breakwall++;
					}
				}
			}
		}

		fprintf(fp, "\n");
		fprintf(fp, "|");
		for (i = 0; i < n; i++)
		{
			if (r[0][i].right == 0)
				fprintf(fp, "  ");
			else
				fprintf(fp, " |");
		}

		fprintf(fp, "\n+");
		for (i = 0; i < n; i++)
		{
			if (r[0][i].down == 0)
				fprintf(fp, " +");
			else
				fprintf(fp, "-+");
		}

		for (i = 0; i < n; i++)
		{
			r[0][i].num = r[1][i].num;
			r[0][i].down = 1;
			r[1][i].num = num;
		}
		c++;
	}

	for (i = 0; i < n - 1; i++)
	{
		if (r[0][i].num == r[0][i + 1].num)
			r[0][i].right = 1;
		else
		{
			for (j = i + 2; j < n; j++)
				if (r[0][j].num == r[0][i + 1].num)
					r[0][j].num = r[0][i].num;
			r[0][i].right = 0;
			r[0][i + 1].num = r[0][i].num;
		}
	}
	r[0][n - 1].right = 1;
	fprintf(fp, "\n");
	fprintf(fp, "|");
	for (i = 0; i<n; i++)
	{
		if (r[0][i].right == 0)
			fprintf(fp, "  ");
		else
			fprintf(fp, " |");
	}
	fprintf(fp, "\n");
	for (i = 0; i<n; i++)
	{
		fprintf(fp, "+");
		fprintf(fp, "-");
	}
	fprintf(fp, "+");

	return 0;
}