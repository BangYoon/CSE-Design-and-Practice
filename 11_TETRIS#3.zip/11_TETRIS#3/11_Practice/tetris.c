#include "tetris.h"

static struct sigaction act, oact;

int main()
{
	int exit=0;

	initscr();
	noecho();
	keypad(stdscr, TRUE);	

	srand((unsigned int)time(NULL));
        createRankList();

	while(!exit)
	{
		clear();
		switch(menu())
		{
			case MENU_PLAY: play(); break;
               		case MENU_RANK: rank(); break;
			case MENU_REC_PLAY: recommendedPlay(); break;
			case MENU_EXIT: exit=1; break;
			default: break;
		}
	}
	endwin();
        writeRankFile();
	system("clear");
	return 0;
}

void InitTetris()
{
	int i,j;

	for(j=0;j<HEIGHT;j++)
		for(i=0;i<WIDTH;i++)
			field[j][i]=0;

	start_color();
	init_color(COLOR_RED,0,1000,0);
	for(i = 1; i<8; i++)
		init_pair(i,i,0);

	nextBlock[0]=rand()%7;
	nextBlock[1]=rand()%7;
        nextBlock[2]=rand()%7;
	blockRotate=0;
	blockY=-1;
	blockX=WIDTH/2-2;
	score=0;	
	gameOver=0;
	timed_out=0;

	recRoot=(RecNode*)malloc(sizeof(RecNode));
  	recRoot->depth=-1;
  	recRoot->accumulatedScore=0;
  	for(i=0;i<HEIGHT;i++)
	{
    		for(j=0;j<WIDTH;j++)
      			recRoot->recField[i][j]=field[i][j];
  	}
  	recommend(recRoot);

	DrawOutline();
	DrawField();
	DrawBlock(blockY,blockX,nextBlock[0],blockRotate,' ');
	DrawBlockWithFeatures(blockY,blockX,nextBlock[0],blockRotate);
	DrawNextBlock(nextBlock);
	PrintScore(score);
}

void DrawOutline()
{	
	int i,j;
	DrawBox(0,0,HEIGHT,WIDTH);

	move(2,WIDTH+10);
	printw("NEXT BLOCK");
	DrawBox(3,WIDTH+10,4,8);
	DrawBox(9,WIDTH+10,4,8);
	
	move(15,WIDTH+10);
	printw("SCORE");
	DrawBox(16,WIDTH+10,1,8);
}

int GetCommand()
{
	int command;
	command = wgetch(stdscr);
	switch(command)
	{
		case KEY_UP:
			break;
		case KEY_DOWN:
			break;
		case KEY_LEFT:
			break;
		case KEY_RIGHT:
			break;
		case ' ':	/* space key*/
			/*fall block*/
			break;
		case 'q':
		case 'Q':
			command = QUIT;
			break;
		default:
			command = NOTHING;
			break;
	}
	return command;
}

int ProcessCommand(int command)
{
	int ret=1;
	int drawFlag=0;
	switch(command)
	{
		case QUIT:
			ret = QUIT;
			break;
		case KEY_UP:
			if((drawFlag = CheckToMove(field,nextBlock[0],(blockRotate+1)%4,blockY,blockX)))
				blockRotate=(blockRotate+1)%4;
			break;
		case KEY_DOWN:
			if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY+1,blockX)))
				blockY++;
			break;
		case KEY_RIGHT:
			if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY,blockX+1)))
				blockX++;
			break;
		case KEY_LEFT:
			if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY,blockX-1)))
				blockX--;
			break;
		default:
			break;
	}
	if(drawFlag) DrawChange(field,command,nextBlock[0],blockRotate,blockY,blockX);
	return ret;	
}

void DrawField()
{
	int i,j;
	for(j=0;j<HEIGHT;j++)
	{
		move(j+1,1);
		for(i=0;i<WIDTH;i++)
		{
			if(field[j][i]==1)
			{
				attron(A_REVERSE);
				attron(COLOR_PAIR(field[j][i]));
				printw(" ");
				attroff(COLOR_PAIR(field[j][i]));
				attroff(A_REVERSE);
			}
			else printw(".");
		}
	}
}

void PrintScore(int score)
{
	move(17,WIDTH+11);
	printw("%8d",score);
}

void DrawNextBlock(int *nextBlock)
{
	int i, j;
	for( i = 0; i < 4; i++ )
	{
		move(4+i,WIDTH+13);
		for( j = 0; j < 4; j++ )
		{
			if( block[nextBlock[1]][0][i][j] == 1 )
			{
				attron(A_REVERSE);
//				attron(COLOR_PAIR(nextBlock[1]+1));	
				printw(" ");
//				attroff(COLOR_PAIR(nextBlock[1]+1));
				attroff(A_REVERSE);
			}
			else printw(" ");
		}
	}
        for( i = 0; i < 4; i++ )
	{
		move(10+i,WIDTH+13);
		for( j = 0; j < 4; j++ )
		{
			if( block[nextBlock[2]][0][i][j] == 1 )
			{
				attron(A_REVERSE);
//				attron(COLOR_PAIR(nextBlock[2]+1));	
				printw(" ");
//				attroff(COLOR_PAIR(nextBlock[2]+1));
				attroff(A_REVERSE);
			}
			else printw(" ");
		}
	}
}

void DrawBlock(int y, int x, int blockID,int blockRotate,char tile)
{
	int i,j;
	for(i=0;i<4;i++)
		for(j=0;j<4;j++)
		{
			if(block[blockID][blockRotate][i][j]==1 && i+y>=0)
			{
				move(i+y+1,j+x+1);
				attron(A_REVERSE);
//				attroff(COLOR_PAIR(nextBlock[0]+1));
				printw("%c",tile);
//				attroff(COLOR_PAIR(nextBlock[0]+1));
				attroff(A_REVERSE);
			}
		}

	move(HEIGHT,WIDTH+10);
}

void DrawBox(int y,int x, int height, int width)
{
	int i,j;
	move(y,x);
	addch(ACS_ULCORNER);
	for(i=0;i<width;i++)
		addch(ACS_HLINE);
	addch(ACS_URCORNER);
	for(j=0;j<height;j++)
	{
		move(y+j+1,x);
		addch(ACS_VLINE);
		move(y+j+1,x+width+1);
		addch(ACS_VLINE);
	}
	move(y+j+1,x);
	addch(ACS_LLCORNER);
	for(i=0;i<width;i++)
		addch(ACS_HLINE);
	addch(ACS_LRCORNER);
}

void play()
{
	int command;
	clear();
	act.sa_handler = BlockDown;
	sigaction(SIGALRM,&act,&oact);
	InitTetris();
	do
	{
		if(timed_out==0)
		{
			alarm(1);
			timed_out=1;
		}

		command = GetCommand();
		if(ProcessCommand(command)==QUIT)
		{
			alarm(0);
			DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
			move(HEIGHT/2,WIDTH/2-4);
			printw("Good-bye!!");
			refresh();
			getch();

			return;
		}
	}while(!gameOver);

	alarm(0);
	getch();
	DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
	move(HEIGHT/2,WIDTH/2-4);
	printw("GameOver!!");
	refresh();
	getch();
	newRank(score);
}

char menu()
{
	printw("1. play\n");
	printw("2. rank\n");
	printw("3. recommended play\n");
	printw("4. exit\n");
	return wgetch(stdscr);
}

int CheckToMove(char f[HEIGHT][WIDTH],int currentBlock,int blockRotate, int blockY, int blockX)
{
  	int i,j;
  	for (i=0;i<4;i++)
  	{
    		for(j=0;j<4;j++)
    		{
    			if(block[currentBlock][blockRotate][i][j]==1 && (i+blockY)>=HEIGHT)       
       				return 0;
     			if(block[currentBlock][blockRotate][i][j]==1 && (j+blockX)<0)
       				return 0;
     			if(block[currentBlock][blockRotate][i][j]==1 &&(j+blockX)>=WIDTH)
       				return 0;
    	 		if(block[currentBlock][blockRotate][i][j]==1 && f[i+blockY][j+blockX]==1)
        			return 0;
    		}
  	}
  	return 1;
}

void DrawChange(char f[HEIGHT][WIDTH],int command,int currentBlock,int blockRotate, int blockY, int blockX)
{
  	int i,j;
  	int prev_X;
  	int prev_Y;
  	int prev_rotate;
  	int ground;
  	prev_X=blockX;
  	prev_Y=blockY;
  	prev_rotate=blockRotate;

  	switch(command)
  	{
    		case KEY_LEFT:
      			prev_X++;
      			break;
    		case KEY_RIGHT:
      			prev_X--;
      			break;
    		case KEY_UP:
      			prev_rotate=(blockRotate+4-1)%4;
      			break;
    		case KEY_DOWN:
      			prev_Y--;
      			break;
  	}
  	ground=prev_Y;
  	while(CheckToMove(field,nextBlock[0],prev_rotate,ground,prev_X))
   		ground++;
  
  	for(i=0;i<4;i++)
  	{
    		for(j=0;j<4;j++)
   	 	{
      			if(block[currentBlock][prev_rotate][i][j]==1)
      			{
        			f[i+prev_Y][j+prev_X]='.';
        			move(i+prev_Y+1,j+prev_X+1);
        			printw("%c",f[i+prev_Y][j+prev_X]);
      			}
      			if(block[currentBlock][prev_rotate][i][j]==1)
      			{
        			f[i+ground-1][j+prev_X]='.';
        			move(i+ground,j+prev_X+1);
        			printw("%c",f[i+ground-1][j+prev_X]);
      			} 
    		}
  	}
  	DrawBlockWithFeatures(blockY,blockX,currentBlock,blockRotate);  
  	move(HEIGHT+100,WIDTH+100);
}

void BlockDown(int sig)
{
  	int i, j;
 	int score_add;
  	if(CheckToMove(field,nextBlock[0],blockRotate,blockY+1,blockX))
  	{
    		blockY++;
    		DrawChange(field,KEY_DOWN,nextBlock[0],blockRotate,blockY,blockX);
  	}
  	else
  	{
    		if(blockY==-1)
      		gameOver=1;
    		score_add=AddBlockToField(field,nextBlock[0],blockRotate,blockY,blockX);
    		score+=DeleteLine(field);
    		score=score+score_add;
    		blockY=-1;
    		blockX=(WIDTH/2)-2;
    		blockRotate=0;
    		nextBlock[0]=nextBlock[1];
    		nextBlock[1]=nextBlock[2];
    		nextBlock[2]=rand()%7;

		recRoot->accumulatedScore=0;
    		for(i=0 ;i<HEIGHT;i++)	
		{
      			for(j=0;j<WIDTH;j++)
				recRoot->recField[i][j]=field[i][j];
    		}		
    		recommend(recRoot);

    		DrawNextBlock(nextBlock);
    		PrintScore(score);
    		DrawField();
		DrawBlockWithFeatures(blockY,blockX,nextBlock[0],blockRotate);///////////////
  	}
  	timed_out=0;
}

int AddBlockToField(char f[HEIGHT][WIDTH],int currentBlock,int blockRotate, int blockY, int blockX)
{ 
  	int i,j;
  	int touched=0;
  	int score=0;
  	for(i=0;i<4;i++)
  	{
    		for(j=0;j<4;j++)
    		{
      			if(block[currentBlock][blockRotate][i][j]==1 && blockY+i+1==HEIGHT)
        			touched++;
      			else if(block[currentBlock][blockRotate][i][j]==1 && f[blockY+i+1][blockX+j]==1)
        			touched++;
    		}
  	}
  
	for(i=0;i<4;i++)
  	{
    		for(j=0;j<4;j++)
    		{
      			if(block[currentBlock][blockRotate][i][j]==1)
        			field[blockY+i][blockX+j]=1;
    		}
  	}
  	score=touched*10;
  	return score;
}

int DeleteLine(char f[HEIGHT][WIDTH])
{
  	int i,j,k;
  	int delete=0;
  	for(i=0;i<HEIGHT;i++)
  	{
    		for(j=0;j<WIDTH;j++)
      			if(f[i][j]!=1)
        			break;
   
    		if(j==WIDTH)
    		{
      			delete++;
      			for(j=0;j<WIDTH;j++)
        			f[i][j]=0;

      			for(k=i-1;k>=0;k--)
        			for(j=0;j<WIDTH;j++)
          				f[k+1][j]=f[k][j];  
    		}
  	}
  	return delete*delete*100;
}

void DrawShadow(int y, int x, int blockID,int blockRotate)
{
  	int ground;
 	ground=y;
  	while(CheckToMove(field,nextBlock[0],blockRotate,ground,x))
    		ground++;
  
  	DrawBlock(ground-1,x,blockID,blockRotate,'/');
}

void DrawBlockWithFeatures(int y, int x, int blockID,int blockRotate)
{
  	DrawBlock(y,x,blockID,blockRotate,' ');
  	DrawShadow(y,x,blockID,blockRotate);
	DrawRecommend(recRoot->recBlockY,recRoot->recBlockX,blockID,recRoot->recBlockRotate);
}
void createRankList()
{
  	int i;
  	FILE* fpoint;
  	Node* current_Node=NULL;
  	Node* newNode=NULL;
  	start_Node=(Node*)malloc(sizeof(Node));
  	fpoint=fopen("rank.txt","r");
  	fscanf(fpoint,"%d",&rank_size);
  	for(i=0;i<rank_size;i++)
  	{
    		if(i==0)
    		{
      			fscanf(fpoint,"%s %d",start_Node->name,&start_Node->score);
 			start_Node->next=NULL;
      			current_Node=start_Node;
    		}
    		else
    		{
      			newNode=(Node*)malloc(sizeof(Node));
      			fscanf(fpoint,"%s %d",newNode->name,&newNode->score);
      			newNode->next=NULL;
      			current_Node->next=newNode;
      			current_Node=newNode;
    		}
  	}
  	fclose(fpoint);
}

void rank()
{
  	Node* current_Node;
  	Node* temp_Node;
  	int i;
  	int flag=0;
  	int from=0, to=0;
  	int rank;
 	char searchname[NAMELEN];
  	clear();
  	printw("1.List ranks from X to Y\n");
  	printw("2.List ranks by specific name\n");
  	printw("3.delete a specific rank\n");
  	
	switch(wgetch(stdscr))
  	{
    		case  '1':
          		echo();
       	   		printw("X: ");
          		scanw("%d",&from);
          		printw("Y: ");
          		scanw("%d",&to);
          		noecho();
          
			if(from==0)
            			from=1;
          		if(to==0)
            			to=rank_size;
       			printw("name\t\t|score\t\t\n");
          		printw("-----------------------------------\n");
          		if(from>to)
            			printw("Search failure: no rank in the list\n");
          		else
          		{
        			current_Node=start_Node;
           			for(i=0;i<rank_size;i++)
            			{
              				if(i>=from-1 && i<=to-1)
                				printw("%s\t\t|%d\t\t\n",&current_Node->name,current_Node->score);
             					current_Node=current_Node->next;
            			}
          		}
          		break;
    		
		case '2':
          		echo();
          		printw("Input the name: ");
          		scanw("%s",&searchname);
          		noecho();
          		printw("name\t\t|score\t\t\n");
          		printw("-----------------------------------\n");

          		current_Node=start_Node;
          		for(i=0;i<rank_size;i++)
          		{
            			if(strcmp(searchname,current_Node->name)==0)
           	 		{
              				printw("%s\t\t|%d\t\t\n",&current_Node->name,current_Node->score);
              				flag=1;
            			}
           	 		current_Node=current_Node->next;
          		}
          		if(flag==0)
            			printw("Search failure: no information in the list\n");
          		break;
    
		case '3':
          		echo();
          		printw("Input the rank:");
          		scanw("%d",&rank);
          		noecho();
          		if(rank>rank_size ||rank<1)
            			printw("Search failure: the rank not in the list\n");
          		else if(rank==rank_size)
          		{
            			current_Node=start_Node;
            			while(current_Node->next->next!=NULL)
              				current_Node=current_Node->next;
            			free(current_Node->next);
            			current_Node->next=NULL;
            			printw("result: the rank deleted\n");
            			rank_size--;
          		}
          
			else if(rank==1)
          		{
            			current_Node=start_Node->next;
            			free(start_Node);
            			start_Node=current_Node;
            			printw("result: the rank deleted\n");
            			rank_size--;
          		}
          		
			else if(rank>1 && rank<rank_size)
          		{
            			current_Node=start_Node;
            			for(i=0;i<rank-2;i++)
              				current_Node=current_Node->next;
            			temp_Node=current_Node->next->next;
            			free(current_Node->next);
            			current_Node->next=temp_Node;
            			printw("result: the rank deleted\n");
            			rank_size--;
          		}
          		break;

		default:break;
  	}
  	getch();
}

void writeRankFile()
{
  	FILE* fpoint;
  	int i;
  	Node* current_Node;
  	Node* temp;
  	current_Node=start_Node;
  	fpoint=fopen("rank.txt","w");
  	fprintf(fpoint,"%d\n",rank_size);
  	while(current_Node->next!=NULL)
  	{
    		fprintf(fpoint,"%s\t%d\n",current_Node->name,current_Node->score);
    		current_Node=current_Node->next;
  	}
  	fprintf(fpoint,"%s\t%d\n",current_Node->name,current_Node->score);
  	fclose(fpoint);
  	current_Node=start_Node;
  	for(i=0;i<rank_size;i++)
  	{
    		temp=current_Node->next;
   	 	free(current_Node);
    		current_Node=temp;
  	}
}

void newRank(int score)
{
  	Node* current_Node;
  	Node* NewNode;
  	int i;
  	int flag=0;
  	clear();
  	current_Node=start_Node;
  	NewNode=(Node*)malloc(sizeof(Node));
  	NewNode->score=score;
  	echo();
  	printw("Your name: ");
  	scanw("%s",NewNode->name);
  	noecho();
  
	for(i=0;i<rank_size;i++)
  	{
    		if(current_Node->next==NULL && current_Node->score>score)
    		{
      			flag=1;
      			break;
    		}
    		if(current_Node->score<=score)
      			break;
    		
		current_Node=current_Node->next;
  	}
  
	rank_size++;
 	if(i==0)
  	{
    		NewNode->next=start_Node;
    		start_Node=NewNode;
  	}

  	else if(flag==1)
  	{
    		current_Node->next=NewNode;
    		NewNode->next=NULL;
  	}
  	else
  	{
    		NewNode->next=current_Node->next;
    		current_Node->next=NewNode;
  	}
}

void DrawRecommend(int y, int x, int blockID,int blockRotate)
{
	// user code
	DrawBlock(y, x, blockID, blockRotate, 'R');
}

int recommend(RecNode* root)
{
	int r,x,y, a, b, i=0, k;
	int R[7]={2,4,4,4,1,2,2};
	int max=0;

	// user code
	if(root->depth == VISIBLE_BLOCKS)//현재 고려라는 level이 최대 level수와 같은 경우
		return 0;

  	if(root->depth < VISIBLE_BLOCKS-1)//현재 고려하는 lecel이 최대 level수보다 작은 경우 >> 누적 계산하기 위해 재귀
	{ 
    		for(r=0;r<R[nextBlock[root->depth+1]];r++)
		{
      			for(x=-1;x<WIDTH;x++)
			{  
				if(CheckToMove(root->recField,nextBlock[root->depth+1],r,0,x))//블록이 필드로 이동할 수 있으면
				{
	  				root->child[i] = (RecNode*)malloc(sizeof(RecNode));
	  				for(a=0;a<HEIGHT;a++)
	    					for(b=0;b<WIDTH;b++)
	      						root->child[i]->recField[a][b] = root->recField[a][b]; //노드 구성하는 정보 저장

					root->child[i]->depth = root->depth+1;//root level plus
	  				root->child[i]->recBlockY = -1;//child node recBlockY
	  				while(CheckToMove(root->recField, nextBlock[root->child[i]->depth],r,root->child[i]->recBlockY+1,x))
		    				root->child[i]->recBlockY++;

	  				root->child[i]->recBlockX = x;
	  				root->child[i]->recBlockRotate = r;
	  				recommend(root->child[i]);//recursive
	  				i++;
				}
      			}
    		}

    		for(k=0;k<i;k++)
		{
      			if(root->child[k]->accumulatedScore > max || root->child[k]->recBlockY > recRoot->recBlockY) //현재 최대보다 큰 경우가 나오면 max 갱신
			{
				max = root->child[k]->accumulatedScore;            
				if(root->depth<0)
				{ 
	  				recRoot->recBlockX = root->child[k]->recBlockX;
	  				recRoot->recBlockY = root->child[k]->recBlockY;
	  				recRoot->recBlockRotate = root->child[k]->recBlockRotate;
				}
      			}
    		}

    		for(k=0;k<i;k++)
      			free(root->child[k]); 
    
		root->accumulatedScore = max; 
	    	if(root->depth<0)
		{    //gameover
      			for(a=0;a<BLOCK_HEIGHT;a++)
			{
				for(b=0;b<BLOCK_WIDTH;b++)
				{
	  				if((block[nextBlock[0]][recRoot->recBlockRotate][a][b] == 1) && field[recRoot->recBlockY+a][recRoot->recBlockX+b] == 1)
					{
	    					gameOver = 1;
	    					return 0;
	  				}
				}
      			}
      			return 0;
    		}
  	}
	return max;
}

void recommendedPlay()
{
	// user code
	int i;
  	clear();
  	start = time(NULL);	// start the counting time
  	act.sa_handler = BlockDown;
  	sigaction(SIGALRM,&act,&oact);

  	InitTetris();
  	do
	{
    		if(timed_out == 0)
		{
      			alarm(1);
      			timed_out = 1;
    		}

    		DrawBlock(-1, WIDTH/2-2, nextBlock[0],0,' ');

    		blockX = recRoot->recBlockX;     
    		blockY = recRoot->recBlockY;      
    		blockRotate = recRoot->recBlockRotate;        

    		DrawRecommend(blockY, blockX , nextBlock[0], blockRotate); 

    		for(i=0 ; i<WIDTH ; i++)
      			if(field[0][i] == 1)    //gameover 
				gameOver = 1;

    		if(gameOver == 1)
      			break;

    		if(GetCommand() == QUIT)
		{
      			stop = time(NULL);	// end the counting time
      			move(25,WIDTH+11);
      			alarm(0);
      			DrawBox(HEIGHT/2-1, WIDTH/2-5, 1, 10);
      			move(HEIGHT/2, WIDTH/2-4);
      			printw("Good-bye!!");
      			refresh();
      			getch();

      			return;
    		}
  	}while(!gameOver);

  	alarm(0);
  	getch();
  	DrawBox(HEIGHT/2-1, WIDTH/2-5, 1, 10);
  	move(HEIGHT/2, WIDTH/2-4);
  	printw("GameOver!!");
  	refresh();
 	getch();
}
