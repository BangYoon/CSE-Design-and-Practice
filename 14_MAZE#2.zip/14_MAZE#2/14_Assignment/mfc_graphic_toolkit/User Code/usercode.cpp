#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include "..\ExternDoc.h"
#include "..\UI\Zoom.h"
#include "..\UI\MsgView.h"
#include "..\Graphics\DrawFunc.h"
#include "..\Example\Example.h"

#define ERROR_NUMBER -1

//function prototype

static void drawDirect(CDC *pDC);
static void drawBuffered();

//Start of user code
#include <float.h>

/*****************************************************************
* function	: bool readFile(const char* filename)
* argument	: cons char* filename - filename to be opened
* return	: true if success, otherwise flase
* remark	: After read data file, phisycal view must be set;
*			  otherwise drawing will not be executed correctly.
*			  The window will be invalidated after readFile()
*			  returns true.
******************************************************************/

typedef struct maze* pmaze;
typedef struct maze 
{
	int up;
	int down;
	int right;
	int left;
}maze;

pmaze* Maze;
char** c;
int M, N;
int free_flag;

bool readFile(const char* filename)
{
	//start of the user code
	FILE* fp;
	int i, j, height, width;
	char tmp;

	fp = fopen(filename, "r");
	if (!fp)
		return false;
	N = 0;
	M = 1;

	while (fscanf(fp, "%c", &tmp) != EOF) //�Է°� ���������� >> N ���
	{
		if (tmp != '+'&& tmp != '-')
			break;
		N++; 
	}
	while (fscanf(fp, "%c", &tmp) != EOF)  //�Է°� ���������� >> M ���
	{
		if (tmp != '+'&& tmp != '-' && tmp != ' '&& tmp != '|')
			M++;
	}

	fclose(fp); 
	//������ ù�ٺ��� �о�;� �ϱ� ������ ���� �ݰ� �ٽ� ����
	fp = fopen(filename, "r"); 

	c = (char**)malloc(sizeof(char*)*(M + 2)); //���������� N, M���� 2���� �迭 ����
	for (i = 0; i < M + 2; i++)
		c[i] = (char*)malloc(sizeof(char)*(N + 2));
	
	for (i = 0; i < M + 2; i++) //���پ� �о�ͼ� �迭�� ����
	{
		for (j = 0; j < N + 2; j++) 
		{
			fscanf(fp, "%c", &tmp);
			c[i][j] = tmp;
			if (tmp == '\n' || tmp == '\0')
			{
				c[i][j] = '\0';
				break;
			}
		}
		if (tmp == '\0') break;
	}

	width = --N / 2; // ���� ���
	height = M / 2;  //���� ���

	Maze = (pmaze*)malloc(sizeof(pmaze)*height); 
	for (i = 0; i < height; i++)  //2���� �迭 ���� �� 0���� �ʱ�ȭ
	{
		Maze[i] = (pmaze)malloc(sizeof(maze)*width);
		for (j = 0; j < width; j++)
		{
			Maze[i][j].down = 0;
			Maze[i][j].up = 0;
			Maze[i][j].left = 0;
			Maze[i][j].right = 0; 
		}
	}
	
	for (i = 0; i < M; i++) //���� ������ ���� maze 2�� �迭���� �� �� �ִ� ��ġ�� 1�� ǥ��
	{
		if (i % 2 == 1) 
		{
			for (j = 0; j < N; j++) 
			{
				if (j % 2 == 1) 
				{
					if (c[i][j - 1] == '|')
						Maze[i / 2][j / 2].left = 1; 
					if (c[i][j + 1] == '|') 
						Maze[i / 2][j / 2].right = 1;
					if (c[i - 1][j] == '-') 
						Maze[i / 2][j / 2].up = 1;
					if (c[i + 1][j] == '-') 
						Maze[i / 2][j / 2].down = 1;
				}
			}
		}
	}
	
	setWindow(0, 0, N / 2, M / 2, 1); //�Ϲ� ��ǥ���� (0,0) ���� (N/2,M/2)������ Window ��ǥ��� ���� (������ �� 0 -> 1)
	fclose(fp);

	return true; //edit after finish this function
	//end of usercode
}

/******************************************************************
* function	: bool FreeMemory()
*
* remark	: Save user data to a file
*******************************************************************/
void freeMemory()
{
	//start of the user code
	//end of usercode
	int i, j;
	if (free_flag == 1) 
	{
		for (i = 0; i<M / 2; i++)
			free(Maze[i]);
		free(Maze);
		for (j = 0; j<M / 2; j++)
			free(c[j]);
		free(c);
		free_flag = 0;
	}
	else return;
}

/**************************************************************
* function	: bool writeFile(const char* filename)
*
* argument	: const char* filename - filename to be written
* return	: true if success, otherwise false
* remark	: Save user data to a file
****************************************************************/
bool writeFile(const char* filename)
{
	//start of the user code
	bool flag;
	flag = 0;

	return flag;
	//end of usercode
}

/************************************************************************
* fucntion	: void drawMain(CDC* pDC)
*
* argument	: CDC* pDC - device context object pointer
* remark	: Main drawing function. Called by CMFC_MainView::OnDraw()
*************************************************************************/
void drawMain(CDC *pDC)
{
	//if direct drawing is defined
#if defined(GRAPHICS_DIRECT)
	drawDirect(pDC);
	//if buffered drawing is defined
#elif defined(GRAPHICS_BUFFERED)
	drawBuffered();
#endif
}

/************************************************************************
* function	: static void drawDirect(CDC *pDC
*
* argument	: CDC* pDC - device context object pointer
* remark	: Direct drawing routines here.
*************************************************************************/
static void drawDirect(CDC *pDC)
{
	//begin of user code
	//Nothing to write currently.
	//end of user code
}

/***********************************************************************
* function	: static void drawBuffered()
*
* argument	: CDC* pDC -0 device object pointer
* remark	: Buffered drawing routines here.
************************************************************************/
static void drawBuffered()
{
	//start of the user code
	int i, j;

	DrawBox_I(0, 0, N / 2, M / 2, 6, RGB(255, 0, 220)); 
	for (i = 0; i < M; i++)
	{
		if (i % 2 == 1)
		{
			for (j = 0; j < N; j++)
			{
				if (j % 2 == 1)
				{
					if (Maze[i / 2][j / 2].right == 1)
						DrawLine_I(j / 2 + 1, i / 2, j / 2 + 1, i / 2 + 1, 6, RGB(255, 0, 220));
					if (Maze[i / 2][j / 2].down == 1)
						DrawLine_I(j / 2, i / 2 + 1, j / 2 + 1, i / 2 + 1, 6, RGB(255, 0, 220));
				}
			}
		}
	}
	free_flag = 1;
	//end of the user code
}