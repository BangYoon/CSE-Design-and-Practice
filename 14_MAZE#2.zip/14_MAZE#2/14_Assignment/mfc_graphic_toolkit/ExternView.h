#ifndef __EXTERN_VIEW_H__
#define __EXTERN_VIEW_H__

#include "StdAfx.h"
#include "MFC_MainDoc.h"
#include "MFC_MainView.h"

extern CMFC_MainView* g_pView;

#endif	// __EXTERN_VIEW_H__