//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// MFC_Main.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MFC_MATYPE                  129
#define IDC_ZOOM                        130
#define ID_VIEW_FULLVIEW                32771
#define ID_VIEW_ZOOM                    32772
#define ID_TOOLS_TEST                   32773
#define ID_BUTTON32791                  32791
#define ID_TOOLS_DFS                    32792
#define ID_TOOLS_BFS                    32793
#define ID_BUTTON32795                  32795
#define ID_INDICATOR_COORD              59200

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
