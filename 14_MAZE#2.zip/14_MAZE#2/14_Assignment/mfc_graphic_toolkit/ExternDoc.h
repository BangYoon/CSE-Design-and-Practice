#ifndef __EXTERN_DOC_H__
#define __EXTERN_DOC_H__

#include "StdAfx.h"

extern void setDocument(CDocument* pDoc);
extern void setModifiedFlag(bool modified);

#endif	// __EXTERN_DOC_H__